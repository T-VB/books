from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import book

class Author:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data ['last_name']
        self.created_at = data['created_at']
        self.updated_at = data ['updated_at']
        self.favorite_books = []

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM authors;"
        authors = []
        results = connectToMySQL('books').query_db(query)
        for row in results:
            #take information above and parse into object
            authors.append(cls(row))
        return authors 

    @classmethod
    def save(cls,data):
        query = "INSERT INTO authors (first_name, last_name) VALUES (%(first_name)s,%(last_name)s);"
        return connectToMySQL('books').query_db(query, data)
        

    @classmethod
    def unfavorited_authors(cls,data):
        query = "SELCET * from authors WHERE authors.id NOT IN (SELECT author_id FROM favorites WHERE book_id=%(id)s;"
        authors = []
        results = connectToMySQL('books').query_db(query,data)
        for row in results:
            authors.append(cls(row))
        return authors
    
    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM authors LEFT JOIN favorites on authors.id = favorites.authors_id LEFT JOIN books on books.id = favorites.book_id WHERE authors.id = %(id)s;"
        results = connectToMySQL('books').query_db(query,data)
        #creates instance of author object, from row one in results
        author = cls(results[0])
        #append all book objects to the favorites instances list
        for row in results:
            #if there are no favorites currently
            if row['books.id'] == None:
                break
            #add data table model, info you want stored
            data = {
                'id': row['books.id'],
                'title': row['title'],
                'num_of_pages': row['num_of_pages'],
                'created_at': row['created_at'],
                'updated_at': row['updated_at'],
            }
            #append book ojects
            author.favorite_books.append(book.Book(data))
        return author
